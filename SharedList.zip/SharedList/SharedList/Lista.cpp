#include "Lista.h"
Lista::Lista() {
	begin = end = NULL;
}
void Lista::agregarAnimal(string n, string h, string e) {
	Nodo *temp = new Nodo(n, h, e);
	if (end == NULL) {
		begin = end = temp; 
	}
	else {
		end->next = temp;
		end = temp;
	}
}

void Lista::eliminarAnimal(string nombre) {
	Nodo* temp = end; bool muerte = 0; Nodo* aux;
	while (temp != nullptr && (*temp).name != nombre) {
		aux = temp;
		temp= temp->next;
		if (temp == nullptr) cout << "NO ESTA EL ANIMAL EN LA LISTA" << endl;
		if (nombre==temp->name){
			if (temp == begin) { begin = begin->next; }
			else { aux->next = temp->next; delete temp; }
	}
	}
}

void Lista::buscarAnimal(string nombre) {
	Nodo* temp= begin;
	while (temp != NULL) {
		if (temp->name == nombre) { cout << "EL ANIMAL " << temp->name << " PERTENECE AL HABITAD " << temp->habitad << " Y ESTA EN ESTADO " << temp->estado << endl; system("pause"); system("cls"); return; }
		temp = temp->next; 
	}
	cout << "ANIMAL NO ENCONTRADO EN EL ZOO" << endl;
}

void Lista::mostrarLista() {
	Nodo* temp = begin;
	while (temp != NULL) {
		{ cout << "EL ANIMAL " << temp->name << " PERTENECE AL HABITAD " << temp->habitad << " Y ESTA EN ESTADO " << temp->estado << endl; }
		temp = temp->next;
	} system("pause"); system("cls");
}

