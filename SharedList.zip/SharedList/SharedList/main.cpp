#include "Lista.h"
int main() {
	int opc; Lista au; string n, e, h;
	do {
		system("cls");
		cout << "ANIMAL:"; cin >> n;
		cout << "ESTADO"; cin >> e;
		cout << "HABITAD"; cin >> h;

		au.agregarAnimal(n, e, h);

		system("pause");
	} while (opc != 0);
}