#include <string>
#include <iostream>
using namespace std;
#pragma once
class Nodo
{public:
	string name;
	string habitad;
	string estado;
	Nodo* next;
	Nodo* prev;
	Nodo(string name, string habitad, string estado);
};