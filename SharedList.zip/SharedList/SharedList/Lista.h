#pragma once
#include "Nodo.h"

class Lista
{
private:
	Nodo* begin;
	Nodo* end;
public:
	Lista();
	void agregarAnimal(string n, string h, string e);
	void eliminarAnimal(string nombre);
	void buscarAnimal(string nombre);
	void mostrarLista();
};

