#include "Nodo.h"
Nodo::Nodo(string name, string habitad, string estado) { 
	this->name = name; this->habitad = habitad; this->estado = estado; 
	next = nullptr; prev = nullptr; }
